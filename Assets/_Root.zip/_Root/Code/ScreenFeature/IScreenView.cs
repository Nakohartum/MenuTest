﻿using UnityEngine.InputSystem;

namespace Game.Code.ScreenFeature
{
    public interface IScreenView
    {
        ScreenPresenter.ScreenPresenter Presenter { get; }
        void Initialize(ScreenPresenter.ScreenPresenter screenPresenter);
        
        void ChangeHints(UIType type);
        void Show();
        void Hide();
        void OnSubmit();
    }
}