﻿using System;
using System.Collections.Generic;
using Game.Code.InputFeature;
using Unity.VisualScripting;
using UnityEngine;

namespace Game.Code.ScreenFeature.ScreenPresenter
{
    public class ScreenPresenter
    {
        private IScreenView _currentScreen;
        private InputController _inputController;
        private Dictionary<Type, IScreenView> _views = new();

        public ScreenPresenter(InputController inputController)
        {
            _inputController = inputController;
        }

        public void AddActionOnSubmit(Action action)
        {
            _inputController.OnSubmit += action;
        }
        
        public void AddActionOnBack(Action onBack)
        {
            _inputController.OnBack += onBack;
        }
        
        public void RemoveAction(Action action)
        {
            _inputController.OnSubmit -= action;
        }
        
        public void AddScreen(IScreenView screen)
        {
            _views.Add(screen.GetType(), screen);
        }

        public void ChangeScreen(Type screen)
        {
            if(_views.TryGetValue(screen, out var screenView))
            {
                _currentScreen?.Hide();
                _currentScreen = screenView;
                _currentScreen.Show();
            }
        }

        
    }
}