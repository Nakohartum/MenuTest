﻿using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Game.Code.ScreenFeature
{
    public class EntryScreenView : BaseScreenView
    {
        public override void OnSubmit()
        { 
            Presenter.ChangeScreen(typeof(MainMenuScreen));
        }

        public override void OnBack()
        {
            
        }
    }
}