﻿using UnityEngine;

namespace Game.Code.ScreenFeature
{
    public abstract class BaseScreenView : MonoBehaviour, IScreenView
    {
        [SerializeField] protected GameObject _pcHint;
        [SerializeField] protected GameObject _xboxHint;
        [SerializeField] protected GameObject _psHint;
        protected bool _hasAddedAction;

        public ScreenPresenter.ScreenPresenter Presenter { get; private set; }

        protected virtual void OnEnable()
        {
                Presenter?.AddActionOnSubmit(OnSubmit);
                Presenter?.AddActionOnBack(OnBack);
        }

        public void Initialize(ScreenPresenter.ScreenPresenter screenPresenter)
        {
            Presenter = screenPresenter;
            Presenter.AddScreen(this);
        }

        public void ChangeHints(UIType type)
        {
            _pcHint.SetActive(type == UIType.PC);
            _xboxHint.SetActive(type == UIType.Xbox);
            _psHint.SetActive(type == UIType.PS);
        }

        public void Show()
        {
            gameObject.SetActive(true);
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }

        public abstract void OnSubmit();
        public abstract void OnBack();

        protected virtual void OnDisable()
        {
            Presenter?.RemoveAction(OnSubmit);
            _hasAddedAction = false;
        }
    }
}