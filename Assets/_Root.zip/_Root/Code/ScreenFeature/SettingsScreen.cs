﻿using UnityEngine;

namespace Game.Code.ScreenFeature
{
    public class SettingsScreen : BaseScreenView
    {
        public override void OnSubmit()
        {
            
        }

        public override void OnBack()
        {
            Presenter.ChangeScreen(typeof(MainMenuScreen));
        }
    }
}