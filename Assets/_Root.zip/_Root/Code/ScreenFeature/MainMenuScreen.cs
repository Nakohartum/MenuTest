﻿using System;
using Game.Code.Root;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Game.Code.ScreenFeature
{
    public class MainMenuScreen : BaseScreenView
    {
        [SerializeField] private Button _startGameButton; 
        [SerializeField] private Button _continueGameButton; 
        [SerializeField] private Button _settingsButton; 
        [SerializeField] private Button _creditsButton; 

        protected override void OnEnable()
        {
            EventSystem.current.SetSelectedGameObject(_startGameButton.gameObject);
            _settingsButton.onClick.AddListener(GoToSettingsScreen);
            _creditsButton.onClick.AddListener(GoToCreditsScreen);
            base.OnEnable();
        }

        private void GoToCreditsScreen()
        {
            Presenter.ChangeScreen(typeof(CreditsScreen));
        }

        private void GoToSettingsScreen()
        {
            Presenter.ChangeScreen(typeof(SettingsScreen));
        }

        public override void OnSubmit()
        {
            
        }

        public override void OnBack()
        {
            
        }

        protected override void OnDisable()
        {
            base.OnDisable();
            _settingsButton.onClick.RemoveAllListeners();
            _creditsButton.onClick.RemoveAllListeners();
        }
    }
}