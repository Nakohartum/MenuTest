﻿using System;
using Game.Code.InputFeature;
using Game.Code.ScreenFeature;
using Game.Code.ScreenFeature.ScreenPresenter;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Game.Code.Root
{

    public class Root : MonoBehaviour
    {
        
        [SerializeField] private PlayerInput _playerInput;
        [SerializeField] private EntryScreenView _entryScreen;
        [SerializeField] private MainMenuScreen _mainMenuScreen;
        [SerializeField] private SettingsScreen _settingsScreen;
        [SerializeField] private CreditsScreen _creditsScreen;
        private InputController _inputController;
        private UIInputManager _uiInputManager;

        private void Start()
        {
            _uiInputManager = new UIInputManager(_playerInput);
            _inputController = new InputController(_playerInput);
            _uiInputManager.Context.OnInputChanged += _entryScreen.ChangeHints;
            _uiInputManager.Context.OnInputChanged += _mainMenuScreen.ChangeHints;
            _uiInputManager.Context.OnInputChanged += _settingsScreen.ChangeHints;
            _uiInputManager.Context.OnInputChanged += _creditsScreen.ChangeHints;
            var screenPresenter = new ScreenPresenter(_inputController);
            _entryScreen.Initialize(screenPresenter);
            _mainMenuScreen.Initialize(screenPresenter);
            _settingsScreen.Initialize(screenPresenter);
            _creditsScreen.Initialize(screenPresenter);
            _uiInputManager.ApplyCurrentStrategy();
            screenPresenter.ChangeScreen(typeof(EntryScreenView));
        }
    }
}